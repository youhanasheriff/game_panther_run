General Sounds from T-Rex Run 3D ripped by DogToon64.

Credit is optional, but would be nice.